package Graphs;

import java.util.ArrayList;
import java.util.Arrays;

public class MCBM {
	static int V, n, m, match[];
	static ArrayList<Integer>[] adjList;
	static boolean[] vis;
	static int go()
	{
		int matches = 0;
		match = new int[m];
		Arrays.fill(match, -1);
		for(int i = 0; i < n; ++i)
		{
			vis = new boolean[n];
			matches += aug(i);
		}
		return matches;
	}
	static int aug(int u)
	{
		vis[u] = true;
		for(int v : adjList[u])
			if(match[v] == -1 || !vis[match[v]] && aug(match[v]) == 1)
			{
				match[v] = u;
				return 1;
			}
		return 0;
	}
}
