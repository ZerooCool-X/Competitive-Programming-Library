package Math;

public class generate_sequence {
	static long[]coff;
	public static void generate_coff(int order,long[]a) {
		long[][]diff=new long[order][order];
		coff=new long[order];
		diff[0]=a;
		for(int i=1;i<order;i++) {
			for(int j=1;j<order;j++) {
				diff[i][j-1]=diff[i-1][j]-diff[i-1][j-1];
			}
		}
		
		for(int i=0;i<order;i++)coff[i]=diff[i][0];
	}
	public static long nth_term(long n) {
		int order=coff.length;
		long ans=0;
		for(int i=0;i<order;i++) {
			long temp=coff[i];
			for(int j=0;j<i;j++) {
				temp*=(n-j);
				
			}
			for(int j=0;j<order-i;j++) {
				temp*=order-j;
			}
			ans+=temp;
		}
		for(int i=0;i<order;i++) {
			ans/=(i+1);
		}
		return ans;
	}
}
