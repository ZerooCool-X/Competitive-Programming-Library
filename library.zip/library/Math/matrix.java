package Math;

public class matrix {

	public static long[][] matmult(long[][] a, long[][] b) {
		int n = a.length;
		int m = b.length;
		int l = b[0].length;

		long[][] c = new long[n][l];
		for (int i = 0; i < n; i++) {
			for (int k = 0; k < m; k++) {
				for (int j = 0; j < l; j++) {

					c[i][j] = (c[i][j] + a[i][k] * b[k][j]) % mod;

				}

			}
		}
		return c;
	}

	public static long[][] matexo(long[][] a, int n) {
		long[][] ret = new long[a.length][a.length];
		for (int i = 0; i < a.length; i++) {
			ret[i][i] = 1;
		}

		while (n > 0) {
			if (n % 2 == 1) {
				ret = matmult(a, ret);
			}
			a = matmult(a, a);
			n = n / 2;
		}
		return ret;
	}
	static long mod = 1000000007;
}
