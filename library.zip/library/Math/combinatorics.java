package Math;


public class combinatorics {

	static long Pow(long a, long e, long mod) // O(log e)
	{
		a %= mod;
		long res = 1l;
		while (e > 0) {
			if ((e & 1) == 1)
				res = (res * a) % mod;
			a = (a * a) % mod;
			e >>= 1l;
		}
		return res;
	}

	public static pair extendedEuclid(int a, int b)
	{
		if(b == 0) { return new pair(1, 0); }
		pair z=extendedEuclid(b, a % b);
		long x1 =  z.y;
		long y1 = z.x - a / b * z.y;
		return new pair(x1, y1);
	}
	public static long GCD(long a, long b) {
		if (b == 0)
			return a;
		if (a == 0)
			return b;
		return (a > b) ? GCD(a % b, b) : GCD(a, b % a);
	}

	public static long LCM(long a, long b) {
		return a * b / GCD(a, b);
	}

	public static long modinverse(long a, long mod) {
		return Pow(a, mod - 2, mod);
	}

	static void facc(int n) {
		fac = new long[n];
		fac[0] = 1;
		for (int i = 1; i < n; i++) {
			fac[i] = (fac[i - 1] * i) % mod;
		}
	}

	static long nc(int n, int r) {
		if (n < r)
			return 0;

		return ((fac[n] * modinverse(fac[n - r],mod)) % mod * modinverse(fac[r],mod)) % mod;
	}

	static long np(int n, int r) {
		return (nc(n, r) * fac[r]) % mod;
	}

	static long catlan(int n) {
		nc(0, 1);
		return ((fac[2 * n] * modinverse(fac[n],mod)) % mod * modinverse(fac[n + 1],mod)) % mod;
	}

	static class pair implements Comparable<pair> {
		long x;
		long y;
 
		public pair(long x, long y) {
			this.x = x;
			this.y = y;
		}
 
		public String toString() {
			return x + " " + y;
		}
 
		public boolean equals(Object o) {
			if (o instanceof pair) {
				pair p = (pair) o;
				return p.x == x && p.y == y;
			}
			return false;
		}
 
		public int hashCode() {
			return new Double(x).hashCode() * 31 + new Double(y).hashCode();
		}
 
		public int compareTo(pair other) {
			if (this.x == other.x) {
				return Long.compare(this.y, other.y);
			}
			return Long.compare(this.x, other.x);
		}
	}
	static long fac[];
	static long mod = 1000000007;
}
