package Math;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.TreeMap;

public class prime_numbers {

	static long Pow(long a, long e, long mod) // O(log e)
	{
		a %= mod;
		long res = 1l;
		while (e > 0) {
			if ((e & 1) == 1)
				res = (res * a) % mod;
			a = (a * a) % mod;
			e >>= 1l;
		}
		return res;
	}

	public static boolean composite(int n, long a, long d, long s) {
		long x = Pow(a, d, n);
		if (x == 1 || x == n - 1)
			return false;
		for (int i = 1; i < s; i++) {
			x = x * x % n;
			if (x == n - 1)
				return false;
		}
		return true;
	}

	public static boolean isprime(int n) {
		if (n < 2)
			return false;

		int r = 0;
		long d = n - 1;
		while ((d & 1) == 0) {
			d >>= 1;
			r++;
		}

		for (int a : new int[] { 2, 3, 5, 7 }) {
			if (n == a)
				return true;
			if (composite(n, a, d, r))
				return false;
		}
		return true;

	}

	public static void genprime(int n) {
		boolean prime[] = new boolean[n + 1];
		for (int i = 0; i < n; i++)
			prime[i] = true;

		for (int p = 2; p * p <= n; p++) {
			if (prime[p] == true) {
				for (int i = p * p; i <= n; i += p)
					prime[i] = false;
			}
		}
		for (int i = 2; i <= n; i++) {
			if (prime[i] == true) {
				primes.put(i, primes.size());
				primes2.put(primes2.size(), i);
			}

		}

	}

	static void sieveLinear(int N) {
		ArrayList<Integer> primes = new ArrayList<Integer>();
		lp = new int[N + 1]; // lp[i] = least prime divisor of i
		for (int i = 2; i <= N; ++i) {
			if (lp[i] == 0) {
				primes.add(i);
				lp[i] = i;
			}
			int curLP = lp[i];
			for (int p : primes)// all primes smaller than or equal my lowest prime divisor
				if (p > curLP || p * 1l * i > N)
					break;
				else
					lp[p * i] = p;
		}
	}

	public static void primefactorization(int n) {
		int x = n;
		while (x > 1) {
			int lowestDivisor = lp[x];
			while (x % lowestDivisor == 0) {
				primefactors.add(lowestDivisor);
				x /= lowestDivisor;
			}
		}
	}

	static LinkedList<Integer> primefactors = new LinkedList<>();
	static int[] lp;
	static TreeMap<Integer, Integer> primes = new TreeMap<Integer, Integer>();
	static TreeMap<Integer, Integer> primes2 = new TreeMap<Integer, Integer>();
}
