package Strings;

public class Trie {

	final int ALPHABET_SIZE = 26;
	TrieNode root;

	public Trie() {
    	root=new TrieNode();
	}
	public class TrieNode {

		TrieNode[] children = new TrieNode[ALPHABET_SIZE];

		int isEndOfWord;

		TrieNode() {
			isEndOfWord = 0;
			for (int i = 0; i < ALPHABET_SIZE; i++)
				children[i] = null;
		}
	}

	public void insert(String key) {
		int level;
		int length = key.length();
		int index;

		TrieNode pCrawl = root;

		for (level = 0; level < length; level++) {
			index = key.charAt(level) - 'a';
			if (pCrawl.children[index] == null)
				pCrawl.children[index] = new TrieNode();

			pCrawl = pCrawl.children[index];
		}
		pCrawl.isEndOfWord++;
	}

	public int search(String key) {
		int level;
		int length = key.length();
		int index;
		TrieNode pCrawl = root;

		for (level = 0; level < length; level++) {
			index = key.charAt(level) - 'a';

			if (pCrawl.children[index] == null)
				return 0;

			pCrawl = pCrawl.children[index];
		}

		return pCrawl.isEndOfWord;
	}

}
