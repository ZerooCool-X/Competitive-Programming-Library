package Strings;

import java.util.Arrays;

public class suffix_array {

	public static class SuffixArray {

		int[] SA;
		int[] AS;
		String SS;

		public SuffixArray(String S) // has a terminating character (e.g. '$')
		{
			SS = S;
			char[] s = new char[S.length() + 1];
			for (int i = 0; i < S.length(); i++) {
				s[i] = S.charAt(i);
			}
			s[S.length()] = '$';
			int n = s.length, RA[] = new int[n];
			SA = new int[n];

			for (int i = 0; i < n; ++i) {
				RA[i] = s[i];
				SA[i] = i;
			}

			for (int k = 1; k < n; k <<= 1) {
				sort(SA, RA, n, k);
				sort(SA, RA, n, 0);
				int[] tmp = new int[n];

				for (int i = 1, r = 0, s1 = SA[0], s2; i < n; ++i) {
					s2 = SA[i];
					tmp[s2] = RA[s1] == RA[s2] && RA[s1 + k] == RA[s2 + k] ? r : ++r;
					s1 = s2;
				}
				for (int i = 0; i < n; ++i)
					RA[i] = tmp[i];

				if (RA[SA[n - 1]] == n - 1)
					break;
			}
			AS = new int[SA.length];
			for (int i = 0; i < SA.length; i++) {
				AS[SA[i]] = i;
			}
		}

		public String toString() {

			return Arrays.toString(SA);
		}

		public int get(int n) {
			return SA[n];
		}

		public int Substring(String s) { // log(n)*|s|
			int low = 0;
			int high = SA.length;
			int mid = (low + high) / 2;
			int ind = -1;

			while (low < high - 1) {

				if (SS.length() - SA[mid] < s.length()) {

					boolean less = false;
					for (int i = SA[mid]; i < SS.length(); i++) {
						if (SS.charAt(i) > s.charAt(i - SA[mid])) {
							less = true;
							break;
						}
						if (SS.charAt(i) < s.charAt(i - SA[mid])) {
							less = false;
							break;
						}
					}
					if (!less) {
						low = mid;
					} else {
						high = mid;
					}
				} else {
					boolean less = true;
					boolean equal = true;
					for (int i = SA[mid]; i < SA[mid] + s.length(); i++) {
						if (SS.charAt(i) < s.charAt(i - SA[mid]) && equal) {
							less = false;
							equal = false;
							break;
						}
						if (SS.charAt(i) != s.charAt(i - SA[mid])) {
							equal = false;
						}
					}
					if (equal) {
						ind = SA[mid];
					}
					if (!less) {
						low = mid;
					} else {
						high = mid;
					}
				}

				mid = (low + high) / 2;
			}
			return ind;
		}

		public int LastSubstring(String s) { // log(n)*|s|
			int low = 0;
			int high = SA.length;
			int mid = (low + high) / 2;
			int ind = -1;

			while (low < high - 1) {

				if (SS.length() - SA[mid] < s.length()) {

					boolean less = true;
					for (int i = SA[mid]; i < SS.length(); i++) {
						if (SS.charAt(i) < s.charAt(i - SA[mid])) {
							break;
						}
						if (SS.charAt(i) > s.charAt(i - SA[mid])) {
							less = false;
							break;
						}
					}
					if (less) {
						low = mid;
					} else {
						high = mid;
					}
				} else {
					boolean less = true;
					boolean equal = true;
					for (int i = SA[mid]; i < SA[mid] + s.length(); i++) {
						if (SS.charAt(i) > s.charAt(i - SA[mid]) && equal) {
							less = false;
							equal = false;
							break;
						}
						if (SS.charAt(i) != s.charAt(i - SA[mid])) {
							equal = false;
						}
					}
					if (equal) {
						ind = SA[mid];
					}
					if (less) {
						low = mid;
					} else {
						high = mid;
					}
				}

				mid = (low + high) / 2;
			}
			return ind;
		}

		public int CountSubstring(String s) {
			int z = LastSubstring(s);
			if (z == -1)
				return 0;
			return AS[z] - AS[Substring(s)] + 1;
		}

		public void sort(int[] SA, int[] RA, int n, int k) {
			int maxi = Math.max(256, n), c[] = new int[maxi];
			for (int i = 0; i < n; ++i)
				c[i + k < n ? RA[i + k] : 0]++;
			for (int i = 0, sum = 0; i < maxi; ++i) {
				int t = c[i];
				c[i] = sum;
				sum += t;
			}
			int[] tmp = new int[n];
			for (int i = 0; i < n; ++i) {
				int j = SA[i] + k;
				tmp[c[j < n ? RA[j] : 0]++] = SA[i];
			}

			for (int i = 0; i < n; ++i)
				SA[i] = tmp[i];
		}
	}
}
