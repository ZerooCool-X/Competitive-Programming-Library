package Data_Structures;

public class Sparse_Table {
	public static class SparseTable {

		int A[], SpT[][];

		SparseTable(int[] A) {
			int n = A.length;
			this.A = A;
			int k = (int) Math.floor(Math.log(n) / Math.log(2)) + 1;
			SpT = new int[n][k];

			for (int i = 0; i < n; i++)
				SpT[i][0] = A[i];

			for (int j = 1; (1 << j) <= n; j++)
				for (int i = 0; i + (1 << j) - 1 < n; i++)
					SpT[i][j] = Math.min(SpT[i][j - 1], SpT[i + (1 << (j - 1))][j - 1]);
		}

		int query(int i, int j) {
			int k = (int) Math.floor(Math.log(j - i + 1) / Math.log(2));
			return Math.min(SpT[i][k], SpT[j - (1 << k) + 1][k]);
		}
	}
}